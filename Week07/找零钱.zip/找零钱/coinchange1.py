class Solution:
	def coinchange1(coins:List[int],amount:int):
		def dp(n):   #输入一个目标金额 n，返回凑出目标金额 n 的最少***数量。
			if n==0:return 0
			if n<0:return-1
			res=float('inf') #求最小值，所以初始化为正无穷
			for coin in coins:
				subproblem=dp(n-coin)
				if subproblem==-1:continue #子问题无解，跳过
				res=min(res,1+subproblem)
			return res if res!=float('inf') else -1
		return dp(amout)
#时间复杂度O(k * n^k)