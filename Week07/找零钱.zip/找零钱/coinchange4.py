from typing import List
class Solution:
	def coinchange4(self,coins:List[int],amount:int)->int:
		dp=[float('inf')]*(amount+1)
		dp[0]=0
		for coin in coins:
			for x in range(coin,amount+1):
				dp[x]=min(dp[x],dp[x-coin]+1)
			return dp[amount] if dp[amount] !=float('inf') else -1

#时间复杂度：O(Sn)，其中 S 是金额，n 是面额数
#空间复杂度：O(S),DP 数组需要开长度为总金额 S 的空间。